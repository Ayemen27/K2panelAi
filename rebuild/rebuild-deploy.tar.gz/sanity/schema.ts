import { SchemaTypeDefinition } from 'sanity'
import schemas from './schemas'

export const schemaTypes: SchemaTypeDefinition[] = schemas
